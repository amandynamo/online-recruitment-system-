package bean;

public interface Provider {

	String DRIVER="com.mysql.jdbc.Driver";
	String CONNECTION_URL="jdbc:mysql://localhost:3306/RecruitmentDatabase";
	String USERNAME="root";
	String PASSWORD="naveen";
	
}
