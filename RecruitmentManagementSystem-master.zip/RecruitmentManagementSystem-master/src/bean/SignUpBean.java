package bean;

public class SignUpBean {

	private String email,pass,name,dob,gender;
	
	public String getEmail()
	{
		return email;
	}
	
	public void setEmail(String email)
	{
		this.email=email;
	}
	
	public String getPass()
	{
		return pass;
	}
	
	public void setPass(String pass)
	{
		this.pass=pass;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getDOB()
	{
		return dob;
	}
	
	public void setDOB(String dob)
	{
		this.dob=dob;
	}
	
	public String getGender()
	{
		return gender;
	}
	
	public void setGender(String gender)
	{
		this.gender=gender;
	}
	
}
